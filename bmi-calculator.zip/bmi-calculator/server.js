const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000; // Порт для сервера

// Middleware для обработки данных из формы
app.use(bodyParser.urlencoded({ extended: true }));

// Главная страница с HTML-формой
app.get('/', (req, res) => {
    res.send(`
        <form action="/calculate-bmi" method="post" style="text-align: center; margin-top: 50px;">
            <label for="weight" style="display: block; margin-bottom: 10px;">Weight (kg):</label>
            <input type="number" id="weight" name="weight" required style="margin-bottom: 20px; padding: 10px; width: 200px;">
            
            <label for="height" style="display: block; margin-bottom: 10px;">Height (cm):</label>
            <input type="number" id="height" name="height" required style="margin-bottom: 20px; padding: 10px; width: 200px;">
            
            <button type="submit" style="padding: 10px 20px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Calculate BMI
            </button>
        </form>
    `);
});

// Маршрут для расчёта BMI
app.post('/calculate-bmi', (req, res) => {
    const weight = parseFloat(req.body.weight); // Вес в кг
    const heightCm = parseFloat(req.body.height); // Рост в см

    // Проверка на корректные значения
    if (!weight || !heightCm || weight <= 0 || heightCm <= 0) {
        return res.send(`
            <p style="color: red; text-align: center; margin-top: 50px;">Invalid input. Please provide positive numbers for weight and height.</p>
            <a href="/" style="display: block; text-align: center; margin-top: 20px;">Back to calculator</a>
        `);
    }

    const height = heightCm / 100; // Конвертируем сантиметры в метры
    const bmi = weight / (height * height); // Формула расчёта BMI
    let category;
    let color;

    // Устанавливаем категорию и цвет
    if (bmi < 18.5) {
        category = 'Underweight';
        color = 'blue';
    } else if (bmi < 24.9) {
        category = 'Normal weight';
        color = 'green';
    } else if (bmi < 29.9) {
        category = 'Overweight';
        color = 'orange';
    } else {
        category = 'Obese';
        color = 'red';
    }

    // Отправляем результат
    res.send(`
        <div style="text-align: center; margin-top: 50px; font-size: 20px;">
            <p>Your BMI is <span style="color: ${color}; font-weight: bold;">${bmi.toFixed(2)}</span>.</p>
            <p>Category: <span style="color: ${color}; font-weight: bold;">${category}</span>.</p>
            <a href="/" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #007BFF; color: white; border: none; border-radius: 5px; text-decoration: none;">
                Back to calculator
            </a>
        </div>
    `);
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
